#!/bin/bash
# ===========================================
# CHANDRA OCR Docker Runner for Linux/macOS
# ===========================================
# Usage: ./run-chandra.sh [demo|vllm|build|stop|logs|gpu-test|model-test|status|help]
#
# Configuration: Edit .env file to change ports, GPU selection, etc.
# ===========================================

set -e

# ===========================================
# COLORS
# ===========================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
NC='\033[0m'

# ===========================================
# LOAD CONFIGURATION FROM .env
# ===========================================
DEMO_PORT=8046
VLLM_PORT=8000
CUDA_VISIBLE_DEVICES=0
VLLM_GPUS=0
INFERENCE_METHOD=hf

if [ -f ".env" ]; then
    # Export all variables from .env
    set -a
    source .env
    set +a
fi

# ===========================================
# HELPER FUNCTIONS
# ===========================================
log_info()    { echo -e "${BLUE}[INFO]${NC}    $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warn()    { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error()   { echo -e "${RED}[ERROR]${NC}   $1"; }

show_banner() {
    echo ""
    echo -e "${BOLD}${MAGENTA}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${MAGENTA}║                                                              ║${NC}"
    echo -e "${BOLD}${MAGENTA}║              CHANDRA OCR - Docker Runner                     ║${NC}"
    echo -e "${BOLD}${MAGENTA}║                                                              ║${NC}"
    echo -e "${BOLD}${MAGENTA}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

show_help() {
    show_banner
    echo -e "${BOLD}Usage:${NC} ./run-chandra.sh [command]"
    echo ""
    echo -e "${BOLD}Commands:${NC}"
    echo "  demo       - Run Streamlit demo with GPU (HF mode, default)"
    echo "  vllm       - Run vLLM mode (server + demo)"
    echo "  build      - Build Docker images"
    echo "  stop       - Stop all Chandra containers"
    echo "  logs       - Show container logs (follow mode)"
    echo "  logs-all   - Show all logs (not follow mode)"
    echo "  status     - Show container status"
    echo "  gpu-test   - Run GPU performance test"
    echo "  model-test - Test model loading"
    echo "  shell      - Open shell in demo container"
    echo "  clean      - Remove all containers and volumes"
    echo "  help       - Show this help message"
    echo ""
    echo -e "${BOLD}Current Settings (from .env):${NC}"
    echo "  ┌─────────────────────────────────────────┐"
    printf "  │ %-20s │ %-16s │\n" "DEMO_PORT" "${DEMO_PORT}"
    printf "  │ %-20s │ %-16s │\n" "VLLM_PORT" "${VLLM_PORT}"
    printf "  │ %-20s │ %-16s │\n" "INFERENCE_METHOD" "${INFERENCE_METHOD}"
    printf "  │ %-20s │ %-16s │\n" "CUDA_VISIBLE_DEVICES" "${CUDA_VISIBLE_DEVICES}"
    printf "  │ %-20s │ %-16s │\n" "VLLM_GPUS" "${VLLM_GPUS}"
    echo "  └─────────────────────────────────────────┘"
    echo ""
    echo -e "${BOLD}URLs:${NC}"
    echo "  Demo:     http://localhost:${DEMO_PORT}"
    echo "  vLLM API: http://localhost:${VLLM_PORT}/v1"
    echo ""
    echo -e "${BOLD}Examples:${NC}"
    echo "  ./run-chandra.sh demo          # Start demo (HF mode)"
    echo "  ./run-chandra.sh vllm          # Start vLLM server + demo"
    echo "  ./run-chandra.sh logs          # View live logs"
    echo "  ./run-chandra.sh stop          # Stop everything"
    echo ""
}

check_docker() {
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed. Please install Docker first."
        exit 1
    fi
    
    if ! docker info &> /dev/null; then
        log_error "Docker daemon is not running. Please start Docker."
        exit 1
    fi
}

check_nvidia() {
    if ! command -v nvidia-smi &> /dev/null; then
        log_warn "nvidia-smi not found. GPU support may not be available."
        return 1
    fi
    
    if ! docker run --rm --gpus all nvidia/cuda:12.4.1-base-ubuntu22.04 nvidia-smi &> /dev/null; then
        log_warn "NVIDIA Container Toolkit may not be properly configured."
        log_info "Install with: sudo apt-get install -y nvidia-container-toolkit && sudo systemctl restart docker"
        return 1
    fi
    
    return 0
}

create_directories() {
    log_info "Creating data directories..."
    mkdir -p data/input data/output
    log_success "Directories created: data/input, data/output"
}

# ===========================================
# MAIN COMMANDS
# ===========================================

build_images() {
    show_banner
    log_info "Building Chandra OCR Docker images..."
    echo ""
    
    docker-compose build --progress=plain
    
    echo ""
    log_success "Build complete!"
    echo ""
    echo "Next steps:"
    echo "  ./run-chandra.sh demo    # Start demo (HF mode)"
    echo "  ./run-chandra.sh vllm    # Start vLLM mode"
}

start_demo() {
    show_banner
    check_docker
    check_nvidia
    create_directories
    
    echo -e "${BOLD}Starting Chandra OCR Demo (HuggingFace Mode)${NC}"
    echo ""
    echo "┌────────────────────────────────────────────────────────────┐"
    echo "│ Mode: HuggingFace (model loaded directly into GPU memory)  │"
    echo "├────────────────────────────────────────────────────────────┤"
    printf "│ %-20s │ %-37s │\n" "Demo URL" "http://localhost:${DEMO_PORT}"
    printf "│ %-20s │ %-37s │\n" "GPU(s)" "${CUDA_VISIBLE_DEVICES}"
    printf "│ %-20s │ %-37s │\n" "Inference Method" "HuggingFace (hf)"
    echo "└────────────────────────────────────────────────────────────┘"
    echo ""
    
    log_info "Starting container..."
    docker-compose up -d chandra-demo
    
    echo ""
    log_success "Container started!"
    log_warn "First run will download the model (~4GB). This may take several minutes."
    echo ""
    echo "Useful commands:"
    echo "  View logs:  ./run-chandra.sh logs"
    echo "  Status:     ./run-chandra.sh status"
    echo "  Stop:       ./run-chandra.sh stop"
    echo ""
}

start_vllm() {
    show_banner
    check_docker
    check_nvidia
    create_directories
    
    echo -e "${BOLD}Starting Chandra OCR (vLLM Mode)${NC}"
    echo ""
    echo "┌────────────────────────────────────────────────────────────┐"
    echo "│ Mode: vLLM Server + Demo (production setup)                │"
    echo "├────────────────────────────────────────────────────────────┤"
    printf "│ %-20s │ %-37s │\n" "Demo URL" "http://localhost:${DEMO_PORT}"
    printf "│ %-20s │ %-37s │\n" "vLLM API" "http://localhost:${VLLM_PORT}/v1"
    printf "│ %-20s │ %-37s │\n" "vLLM GPU(s)" "${VLLM_GPUS}"
    printf "│ %-20s │ %-37s │\n" "Inference Method" "vLLM (vllm)"
    echo "└────────────────────────────────────────────────────────────┘"
    echo ""
    
    log_info "Starting vLLM server and demo..."
    docker-compose --profile vllm up -d
    
    echo ""
    log_success "Containers starting!"
    log_warn "vLLM server initialization takes 3-10 minutes. Please be patient."
    echo ""
    echo "Useful commands:"
    echo "  View vLLM logs:  docker logs -f chandra-vllm"
    echo "  View Demo logs:  docker logs -f chandra-demo-vllm"
    echo "  Status:          ./run-chandra.sh status"
    echo "  Stop:            ./run-chandra.sh stop"
    echo ""
}

stop_containers() {
    show_banner
    log_info "Stopping all Chandra containers..."
    
    docker-compose down 2>/dev/null || true
    docker-compose --profile vllm down 2>/dev/null || true
    
    log_success "All containers stopped!"
}

show_logs() {
    log_info "Showing logs for running containers..."
    log_info "Press Ctrl+C to exit."
    echo ""
    docker-compose logs -f 2>/dev/null || docker-compose --profile vllm logs -f 2>/dev/null
}

show_all_logs() {
    log_info "Showing all logs..."
    echo ""
    docker-compose logs 2>/dev/null
    docker-compose --profile vllm logs 2>/dev/null
}

show_status() {
    show_banner
    log_info "Container Status:"
    echo ""
    docker-compose ps 2>/dev/null || true
    docker-compose --profile vllm ps 2>/dev/null || true
    echo ""
    
    # Check if demo is accessible
    if curl -sf "http://localhost:${DEMO_PORT}/_stcore/health" > /dev/null 2>&1; then
        log_success "Demo is accessible at http://localhost:${DEMO_PORT}"
    else
        log_warn "Demo is not responding at http://localhost:${DEMO_PORT}"
    fi
    
    # Check if vLLM is accessible
    if curl -sf "http://localhost:${VLLM_PORT}/health" > /dev/null 2>&1; then
        log_success "vLLM server is accessible at http://localhost:${VLLM_PORT}"
    fi
}

run_gpu_test() {
    show_banner
    check_docker
    log_info "Running GPU performance test..."
    echo ""
    docker-compose run --rm chandra-demo gpu-test
}

run_model_test() {
    show_banner
    check_docker
    log_info "Running model loading test..."
    echo ""
    docker-compose run --rm chandra-demo model-test
}

open_shell() {
    show_banner
    check_docker
    log_info "Opening shell in demo container..."
    docker-compose run --rm chandra-demo shell
}

clean_all() {
    show_banner
    log_warn "This will remove all containers and cached data!"
    read -p "Are you sure? (y/N): " -n 1 -r
    echo ""
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        log_info "Stopping containers..."
        docker-compose down -v 2>/dev/null || true
        docker-compose --profile vllm down -v 2>/dev/null || true
        
        log_info "Removing images..."
        docker rmi chandra-ocr:latest 2>/dev/null || true
        
        log_info "Removing cache volume..."
        docker volume rm chandra-hf-cache 2>/dev/null || true
        
        log_success "Cleanup complete!"
    else
        log_info "Cleanup cancelled."
    fi
}

# ===========================================
# MAIN COMMAND HANDLER
# ===========================================
case "${1:-demo}" in
    demo)
        start_demo
        ;;
    vllm)
        start_vllm
        ;;
    build)
        build_images
        ;;
    stop)
        stop_containers
        ;;
    logs)
        show_logs
        ;;
    logs-all)
        show_all_logs
        ;;
    status)
        show_status
        ;;
    gpu-test)
        run_gpu_test
        ;;
    model-test)
        run_model_test
        ;;
    shell)
        open_shell
        ;;
    clean)
        clean_all
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        log_error "Unknown command: $1"
        echo ""
        show_help
        exit 1
        ;;
esac
